# 🔍 Анализ мёртвого кода

## ✅ Помеченные кандидаты на удаление

### Функции без использований:

1. **`parse_price(text: str)`** (строка ~994)
   - Помечено: `# TODO: UNUSED_FUNCTION(parse_price)`
   - Статус: Не найдено использований в коде

2. **`get_all_pools_with_format()`** (строка ~1018)
   - Помечено: `# TODO: UNUSED_FUNCTION(get_all_pools_with_format)`
   - Статус: Не найдено использований в коде

3. **`translate_pool_status(...)`** (строка ~347)
   - Помечено: `# TODO: UNUSED_FUNCTION(translate_pool_status)`
   - Статус: Не найдено использований в коде

4. **`migrate_all_existing_pools()`** (строка ~387)
   - Помечено: `# TODO: UNUSED_FUNCTION(migrate_all_existing_pools)`
   - Статус: Не найдено использований в коде (возможно, миграция уже выполнена)

5. **`migrate_old_pools()`** (строка ~448)
   - Помечено: `# TODO: UNUSED_FUNCTION(migrate_old_pools)`
   - Статус: Не найдено использований в коде

6. **`parse_join_pool_callback(callback_data: str)`** (строка ~558)
   - Помечено: `# TODO: UNUSED_FUNCTION(parse_join_pool_callback)`
   - Статус: Не найдено использований в коде

7. **`validate_batch_volume(batch: dict, pool: dict)`** (строка ~572)
   - Помечено: `# TODO: UNUSED_FUNCTION(validate_batch_volume)`
   - Статус: Не найдено использований в коде

### Handlers-дубликаты:

1. **`reload_data_callback`** (строка ~25571)
   - Помечено: `# TODO: UNUSED_HANDLER(reload_data_callback)` — дубликат на строке 6330
   - Статус: Дубликат handler'а для `/admin reload_data`

2. **`admin_menu`** (строка ~7938)
   - Помечено: `# TODO: UNUSED_HANDLER(admin_menu)` — дубликат на строке 4534
   - Статус: Дубликат handler'а для команды `/admin`

### Handlers без кнопок:

1. **`noop_handler`** (строка ~26650)
   - Помечено: `# TODO: UNUSED_HANDLER(noop_handler)`
   - Статус: Не найдено использований `callback_data="noop"` в коде

## 📊 Статистика

- **Помечено функций:** 7
- **Помечено handlers-дубликатов:** 2
- **Помечено handlers без кнопок:** 1
- **Всего помечено:** 10

## ⚠️ Рекомендации

1. **Перед удалением:**
   - Проверить вручную каждый помеченный элемент
   - Убедиться, что функция/handler действительно не используется
   - Проверить, нет ли динамических вызовов через `getattr()` или `eval()`

2. **Приоритет удаления:**
   - Сначала удалить дубликаты handlers (безопасно)
   - Затем удалить функции миграции (если миграция завершена)
   - В последнюю очередь удалить остальные функции (требует тщательной проверки)

3. **Дальнейший анализ:**
   - Продолжить поиск других неиспользуемых функций
   - Проверить handlers с редкими callback_data
   - Анализировать функции, вызываемые только из других неиспользуемых функций
