# 🗺️ МАППИНГ ПЕРЕИМЕНОВАНИЙ

**Версия:** 1.0  
**Дата:** 2025-01-27  
**Файл:** alpha.py

---

## ЛЕГЕНДА ПРИОРИТЕТОВ

- 🔴 **КРИТИЧНО** - блокеры читаемости, дубликаты
- 🟡 **ВАЖНО** - улучшат навигацию
- 🟢 **ОПЦИОНАЛЬНО** - polish, можно отложить

---

## ТАБЛИЦА ПЕРЕИМЕНОВАНИЙ

| Старое имя | Файл:Строка | Новое имя | Приоритет | Причина |
|------------|-------------|-----------|-----------|---------|
| `pullparticipants` | alpha.py:131 | `pool_participants_storage` | 🔴 | Слитно, нет суффикса, "pull" → "pool" |
| `status_map` | alpha.py:196 | `STATUS_MAP` | 🔴 | Константа должна быть UPPER_CASE |
| `USERSFILE` | alpha.py:102 | `USERS_PKL_FILE` | 🔴 | Смешанный стиль, неконсистентность |
| `BATCHESFILE` | alpha.py:103 | `BATCHES_PKL_FILE` | 🔴 | Смешанный стиль |
| `EXPEDITORSFILE` | alpha.py:104 | `EXPEDITORS_PKL_FILE` | 🔴 | Смешанный стиль |
| `USERS_FILE` | alpha.py:112 | `USERS_JSON_FILE` | 🔴 | Дубликат, уточнить формат |
| `BATCHES_FILE` | alpha.py:113 | `BATCHES_PKL_FILE` | 🔴 | Дубликат с BATCHESFILE |
| `shipping_requests` | alpha.py:166 | **УДАЛИТЬ** | 🔴 | Дубликат (есть на строке 137) |
| `logistics_requests` | alpha.py:167 | **УДАЛИТЬ** | 🔴 | Дубликат (есть на строке 138) |
| `logistic_offers` | alpha.py:168, 170 | **УДАЛИТЬ** | 🔴 | Дубликат (есть на строке 146) |
| `gs` | alpha.py:7463 | `google_sheets_manager` | 🔴 | Однобуквенное имя |
| `adminkeyboard()` | alpha.py:1890 | **УДАЛИТЬ** | 🔴 | camelCase, есть `admin_keyboard()` |
| `generate_id()` | alpha.py:1033 | **УДАЛИТЬ** | 🔴 | Дубликат `generate_unique_id()` |
| `save_logistic_offers()` | alpha.py:1169 | `save_logistics_offers()` | 🔴 | Неконсистентность (logistic vs logistics) |
| `load_logistic_offers()` | alpha.py:1178 | `load_logistics_offers()` | 🔴 | Неконсистентность |
| `AddBatch` | alpha.py:1373 | `AddBatchStates` | 🔴 | Нет суффикса States |
| `EditBatch` | alpha.py:1387 | `EditBatchStates` | 🔴 | Нет суффикса States |
| `DeleteBatch` | alpha.py:1394 | `DeleteBatchStates` | 🔴 | Нет суффикса States |
| `EditProfile` | alpha.py:1400 | `EditProfileStates` | 🔴 | Нет суффикса States |
| `LogisticsOffer` | alpha.py:1430 | `LogisticsOfferStates` | 🔴 | Нет суффикса States |
| `ExpeditorOffer` | alpha.py:1461 | `ExpeditorOfferStates` | 🔴 | Нет суффикса States |
| `Broadcast` | alpha.py:1470 | `BroadcastStates` | 🔴 | Нет суффикса States |
| `SearchByCulture` | alpha.py:1338 | `SearchByCultureStates` | 🔴 | Нет суффикса States |
| `DealView` | alpha.py:28206 | `DealViewStates` | 🔴 | Нет суффикса States |
| `EditCardStates` | alpha.py:24956 | **УДАЛИТЬ** | 🔴 | Дубликат (есть на строке 1605) |
| `pulls` | alpha.py:130 | `pools_storage` | 🟡 | "pull" → "pool", добавить суффикс |
| `translate_pull_status()` | alpha.py:250 | `translate_pool_status()` | 🟡 | "pull" → "pool" |
| `migrate_all_existing_pulls()` | alpha.py:290 | `migrate_all_existing_pools()` | 🟡 | "pull" → "pool" |
| `migrate_old_pulls()` | alpha.py:351 | `migrate_old_pools()` | 🟡 | "pull" → "pool" |
| `find_matching_batches()` | alpha.py:407 | `find_matching_batches_for_pool()` | 🟡 | Уточнить назначение |
| `_batch_matches_pull()` | alpha.py:449 | `_batch_matches_pool()` | 🟡 | "pull" → "pool" |
| `parse_join_pull_callback()` | alpha.py:461 | `parse_join_pool_callback()` | 🟡 | "pull" → "pool" |
| `check_and_close_pool_if_full()` | alpha.py:491 | `check_and_close_pool_if_full()` | 🟡 | OK, но можно `auto_close_pool_if_filled()` |
| `get_pull_with_participants()` | alpha.py:935 | `get_pool_with_participants()` | 🟡 | "pull" → "pool" |
| `get_farmers_from_pull()` | alpha.py:950 | `get_farmers_from_pool()` | 🟡 | "pull" → "pool" |
| `get_batches_from_pull()` | alpha.py:974 | `get_batches_from_pool()` | 🟡 | "pull" → "pool" |
| `get_all_pulls_with_format()` | alpha.py:991 | `get_all_pools_with_format()` | 🟡 | "pull" → "pool" |
| `CreatePullStatesGroup` | alpha.py:1407 | `CreatePoolStatesGroup` | 🟡 | "pull" → "pool" |
| `JoinPullStatesGroup` | alpha.py:1420 | `JoinPoolStatesGroup` | 🟡 | "pull" → "pool" |
| `EditPullStatesGroup` | alpha.py:1499 | `EditPoolStatesGroup` | 🟡 | "pull" → "pool" |
| `join_pull_start()` | alpha.py:4549 | `handle_pool_join_start()` | 🟡 | "pull" → "pool", добавить префикс |
| `find_matching_exporters()` | alpha.py:2917 | `find_matching_pools_for_batch()` | 🟡 | Уточнить назначение |
| `TRANSPORT_TYPES` | alpha.py:184 | `TRANSPORT_TYPE_EMOJIS` | 🟡 | Объединить с TRANSPORT_EMOJIS |
| `TRANSPORT_EMOJIS` | alpha.py:190 | **УДАЛИТЬ** | 🟡 | Дубликат TRANSPORT_TYPES |
| `users` | alpha.py:127 | `users_storage` | 🟢 | Добавить суффикс для ясности |
| `batches` | alpha.py:129 | `batches_storage` | 🟢 | Добавить суффикс |
| `matches` | alpha.py:132 | `matches_storage` | 🟢 | Добавить суффикс |
| `deals` | alpha.py:133 | `deals_storage` | 🟢 | Добавить суффикс |
| `batch_counter` | alpha.py:153 | `next_batch_id` | 🟢 | Более описательно |
| `pull_counter` | alpha.py:154 | `next_pool_id` | 🟢 | "pull" → "pool", более описательно |
| `deal_counter` | alpha.py:155 | `next_deal_id` | 🟢 | Более описательно |
| `match_counter` | alpha.py:156 | `next_match_id` | 🟢 | Более описательно |
| `logistics_request_counter` | alpha.py:157 | `next_logistics_request_id` | 🟢 | Более описательно |
| `logistics_offer_counter` | alpha.py:158 | `next_logistics_offer_id` | 🟢 | Более описательно |
| `expeditor_pull_offers_counter` | alpha.py:175 | `next_expeditor_pool_offer_id` | 🟢 | "pull" → "pool" |
| `expeditor_request_offers_counter` | alpha.py:179 | `next_expeditor_request_offer_id` | 🟢 | OK |
| `finish_quick_batch()` | alpha.py:4887 | `finish_quick_batch()` | 🟢 | Добавить типизацию параметров |

---

## МАССОВЫЕ ЗАМЕНЫ (Regex patterns)

### Замена "pull" → "pool" (кроме комментариев)

**⚠️ ВНИМАНИЕ:** Делать осторожно, проверить контекст!

```bash
# В именах переменных/функций
s/pull_id/pool_id/g
s/pull_data/pool_data/g
s/pull_counter/pool_counter/g  # но лучше next_pool_id
s/pulls_storage/pools_storage/g
s/pullparticipants/pool_participants/g

# В именах функций
s/get_pull/get_pool/g
s/create_pull/create_pool/g
s/join_pull/join_pool/g
s/edit_pull/edit_pool/g

# В именах классов
s/PullStates/PoolStates/g
s/CreatePull/CreatePool/g
s/JoinPull/JoinPool/g
```

### Замена суффиксов для States

```bash
s/class AddBatch(/class AddBatchStates(/g
s/class EditBatch(/class EditBatchStates(/g
s/class DeleteBatch(/class DeleteBatchStates(/g
s/class EditProfile(/class EditProfileStates(/g
s/class LogisticsOffer(/class LogisticsOfferStates(/g
s/class ExpeditorOffer(/class ExpeditorOfferStates(/g
s/class Broadcast(/class BroadcastStates(/g
s/class SearchByCulture(/class SearchByCultureStates(/g
s/class DealView(/class DealViewStates(/g
```

### Замена констант

```bash
s/status_map/STATUS_MAP/g
s/USERSFILE/USERS_PKL_FILE/g
s/BATCHESFILE/BATCHES_PKL_FILE/g
s/EXPEDITORSFILE/EXPEDITORS_PKL_FILE/g
```

---

## ПОРЯДОК ВЫПОЛНЕНИЯ

### Этап 1: Удаление дубликатов (🔴)

1. Удалить `shipping_requests` на строке 166
2. Удалить `logistics_requests` на строке 167
3. Удалить `logistic_offers` на строках 168, 170
4. Удалить функцию `adminkeyboard()` (строка 1890)
5. Удалить функцию `generate_id()` (строка 1033)
6. Удалить класс `EditCardStates` на строке 24956
7. Удалить константу `TRANSPORT_EMOJIS` (объединить с TRANSPORT_TYPES)

### Этап 2: Критические переименования (🔴)

8. `status_map` → `STATUS_MAP`
9. `pullparticipants` → `pool_participants_storage`
10. `USERSFILE` → `USERS_PKL_FILE`
11. `BATCHESFILE` → `BATCHES_PKL_FILE`
12. `EXPEDITORSFILE` → `EXPEDITORS_PKL_FILE`
13. `gs` → `google_sheets_manager`
14. Добавить суффикс `States` ко всем классам States

### Этап 3: Унификация терминологии (🟡)

15. Массовая замена "pull" → "pool" в именах
16. `save_logistic_offers` → `save_logistics_offers`
17. `load_logistic_offers` → `load_logistics_offers`

### Этап 4: Улучшения (🟢)

18. Добавить суффикс `_storage` к глобальным словарям
19. Переименовать счетчики в `next_{entity}_id`
20. Добавить типизацию в функции без аннотаций

---

## ПРОВЕРКА ПОСЛЕ РЕФАКТОРИНГА

```bash
# Проверка на дубликаты
grep -n "shipping_requests\s*=" alpha.py
grep -n "logistic_offers\s*=" alpha.py

# Проверка констант (должны быть UPPER_CASE)
grep -n "^[a-z].*_map\s*=" alpha.py

# Проверка классов States (должны иметь суффикс)
grep -n "^class.*StatesGroup" alpha.py | grep -v "States"

# Проверка типизации
grep -n "^def.*):$" alpha.py | grep -v "->"
grep -n "^async def.*):$" alpha.py | grep -v "->"
```

---

**Итого:** 50+ переименований, из них 25 критических


