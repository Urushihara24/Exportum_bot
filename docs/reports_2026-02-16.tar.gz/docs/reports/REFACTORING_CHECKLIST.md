# ✅ CHECKLIST ДЛЯ БЕЗОПАСНОГО РЕФАКТОРИНГА

**Версия:** 1.0  
**Дата:** 2025-01-27  
**Проект:** Telegram-бот для зернового рынка

---

## ПЕРЕД НАЧАЛОМ РЕФАКТОРИНГА

### 📦 Подготовка

- [ ] **Создан git commit** с текущим состоянием
  ```bash
  git add .
  git commit -m "Backup before naming refactoring"
  ```

- [ ] **Создана ветка** для рефакторинга
  ```bash
  git checkout -b refactor/naming-conventions
  ```

- [ ] **Проверены все импорты** - нет внешних зависимостей от имен
  ```bash
  grep -r "from alpha import" .
  grep -r "import alpha" .
  ```

- [ ] **Учтены строковые ссылки:**
  - [ ] callback_data в inline keyboards
  - [ ] database keys в pickle/JSON
  - [ ] callback query handlers (lambda функции)
  - [ ] строковые константы в коде

- [ ] **Создан бэкап данных:**
  ```bash
  cp -r data/ data_backup_$(date +%Y%m%d)/
  ```

---

## ЭТАП 1: УДАЛЕНИЕ ДУБЛИКАТОВ (🔴 КРИТИЧНО)

### 1.1 Дубликаты переменных

- [ ] Удалить `shipping_requests` на строке 166
- [ ] Удалить `logistics_requests` на строке 167  
- [ ] Удалить `logistic_offers` на строках 168, 170
- [ ] Проверить, что используются только объявления на строках 137-146

**Проверка:**
```bash
grep -n "shipping_requests\s*=" alpha.py
# Должна остаться только одна строка (137)
```

### 1.2 Дубликаты функций

- [ ] Удалить `adminkeyboard()` на строке 1890
- [ ] Удалить `generate_id()` на строке 1033
- [ ] Проверить, что все вызовы используют правильные функции

**Проверка:**
```bash
grep -n "adminkeyboard()" alpha.py
grep -n "generate_id()" alpha.py
# Не должно быть вызовов
```

### 1.3 Дубликаты классов

- [ ] Удалить `EditCardStates` на строке 24956
- [ ] Проверить, что используется только класс на строке 1605

**Проверка:**
```bash
grep -n "class EditCardStates" alpha.py
# Должна остаться только одна строка (1605)
```

### 1.4 Дубликаты констант

- [ ] Объединить `TRANSPORT_TYPES` и `TRANSPORT_EMOJIS` в `TRANSPORT_TYPE_EMOJIS`
- [ ] Удалить `TRANSPORT_EMOJIS`

**Проверка:**
```bash
grep -n "TRANSPORT_EMOJIS" alpha.py
# Не должно быть упоминаний
```

---

## ЭТАП 2: КРИТИЧЕСКИЕ ПЕРЕИМЕНОВАНИЯ (🔴)

### 2.1 Константы

- [ ] `status_map` → `STATUS_MAP` (строка 196)
- [ ] `USERSFILE` → `USERS_PKL_FILE` (строка 102)
- [ ] `BATCHESFILE` → `BATCHES_PKL_FILE` (строка 103)
- [ ] `EXPEDITORSFILE` → `EXPEDITORS_PKL_FILE` (строка 104)
- [ ] `USERS_FILE` → `USERS_JSON_FILE` (строка 112)
- [ ] `BATCHES_FILE` → удалить (дубликат)

**Проверка:**
```bash
grep -n "status_map\|USERSFILE\|BATCHESFILE" alpha.py
# Должны быть только новые имена
```

### 2.2 Глобальные переменные

- [ ] `pullparticipants` → `pool_participants_storage` (строка 131)
- [ ] `gs` → `google_sheets_manager` (строка 7463)

**Проверка:**
```bash
grep -n "pullparticipants\|^gs\s*=" alpha.py
# Должны быть только новые имена
```

### 2.3 Классы States

- [ ] `AddBatch` → `AddBatchStates`
- [ ] `EditBatch` → `EditBatchStates`
- [ ] `DeleteBatch` → `DeleteBatchStates`
- [ ] `EditProfile` → `EditProfileStates`
- [ ] `LogisticsOffer` → `LogisticsOfferStates`
- [ ] `ExpeditorOffer` → `ExpeditorOfferStates`
- [ ] `Broadcast` → `BroadcastStates`
- [ ] `SearchByCulture` → `SearchByCultureStates`
- [ ] `DealView` → `DealViewStates`

**Проверка:**
```bash
grep -n "class AddBatch(\|class EditBatch(\|class DeleteBatch(" alpha.py
# Должны быть только новые имена с суффиксом States
```

---

## ЭТАП 3: УНИФИКАЦИЯ ТЕРМИНОЛОГИИ (🟡)

### 3.1 "pull" → "pool"

**⚠️ ВНИМАНИЕ:** Делать осторожно, проверить контекст каждого случая!

- [ ] `pulls` → `pools_storage` (строка 130)
- [ ] `translate_pull_status()` → `translate_pool_status()`
- [ ] `migrate_all_existing_pulls()` → `migrate_all_existing_pools()`
- [ ] `migrate_old_pulls()` → `migrate_old_pools()`
- [ ] `_batch_matches_pull()` → `_batch_matches_pool()`
- [ ] `parse_join_pull_callback()` → `parse_join_pool_callback()`
- [ ] `get_pull_with_participants()` → `get_pool_with_participants()`
- [ ] `get_farmers_from_pull()` → `get_farmers_from_pool()`
- [ ] `get_batches_from_pull()` → `get_batches_from_pool()`
- [ ] `get_all_pulls_with_format()` → `get_all_pools_with_format()`
- [ ] `CreatePullStatesGroup` → `CreatePoolStatesGroup`
- [ ] `JoinPullStatesGroup` → `JoinPoolStatesGroup`
- [ ] `EditPullStatesGroup` → `EditPoolStatesGroup`
- [ ] `join_pull_start()` → `handle_pool_join_start()`
- [ ] `pull_counter` → `next_pool_id`
- [ ] `expeditor_pull_offers` → `expeditor_pool_offers`
- [ ] `expeditor_pull_offers_counter` → `next_expeditor_pool_offer_id`

**Проверка:**
```bash
# Проверить, что не осталось "pull" в именах (кроме комментариев)
grep -n "pull" alpha.py | grep -v "#\|\"\|'" | grep -v "pullparticipants"
```

### 3.2 Неконсистентность "logistic" vs "logistics"

- [ ] `save_logistic_offers()` → `save_logistics_offers()`
- [ ] `load_logistic_offers()` → `load_logistics_offers()`

**Проверка:**
```bash
grep -n "logistic_offers" alpha.py
# Должно быть "logistics_offers" везде
```

---

## ЭТАП 4: УЛУЧШЕНИЯ (🟢 ОПЦИОНАЛЬНО)

### 4.1 Суффиксы для хранилищ

- [ ] `users` → `users_storage`
- [ ] `batches` → `batches_storage`
- [ ] `matches` → `matches_storage`
- [ ] `deals` → `deals_storage`
- [ ] `logistics_cards` → `logistics_cards_storage`
- [ ] `expeditor_cards` → `expeditor_cards_storage`

### 4.2 Счетчики ID

- [ ] `batch_counter` → `next_batch_id`
- [ ] `deal_counter` → `next_deal_id`
- [ ] `match_counter` → `next_match_id`
- [ ] `logistics_request_counter` → `next_logistics_request_id`
- [ ] `logistics_offer_counter` → `next_logistics_offer_id`

### 4.3 Типизация

- [ ] Добавить типы в `finish_quick_batch(message_or_callback, ...)`
- [ ] Проверить все функции без аннотаций типов

---

## ПОСЛЕ РЕФАКТОРИНГА

### ✅ Проверки

- [ ] **Запущены линтеры:**
  ```bash
  flake8 alpha.py
  pylint alpha.py
  mypy alpha.py  # если установлен
  ```

- [ ] **Проверка синтаксиса:**
  ```bash
  python3 -m py_compile alpha.py
  ```

- [ ] **Проверка импортов:**
  ```bash
  python3 -c "import alpha"
  ```

- [ ] **Обновлены комментарии:**
  - [ ] Docstrings функций
  - [ ] Комментарии в коде
  - [ ] README.md (если есть)

- [ ] **Проверка callback_data:**
  ```bash
  # Найти все callback_data с "pull"
  grep -n "callback_data.*pull" alpha.py
  # Заменить на "pool" где нужно
  ```

- [ ] **Проверка pickle файлов:**
  - [ ] Проверить, что ключи в pickle совместимы
  - [ ] При необходимости создать миграцию данных

- [ ] **Тестирование:**
  - [ ] Запустить бота в тестовом режиме
  - [ ] Проверить основные функции:
    - [ ] Регистрация
    - [ ] Создание пула
    - [ ] Добавление партии
    - [ ] Присоединение к пулу
    - [ ] Уведомления

---

## ОТКАТ ИЗМЕНЕНИЙ (если что-то пошло не так)

```bash
# Откат к последнему коммиту
git reset --hard HEAD

# Или откат конкретного файла
git checkout HEAD -- alpha.py

# Восстановление данных
cp -r data_backup_YYYYMMDD/* data/
```

---

## ПОРЯДОК ВЫПОЛНЕНИЯ (рекомендуемый)

1. **Этап 1** (удаление дубликатов) - 30 минут
2. **Этап 2** (критические переименования) - 1-2 часа
3. **Этап 3** (унификация терминологии) - 2-3 часа
4. **Этап 4** (улучшения) - 1-2 часа

**Общее время:** 4-7 часов работы

---

## КРИТЕРИИ УСПЕХА

✅ Все дубликаты удалены  
✅ Все константы в UPPER_CASE  
✅ Все классы States имеют суффикс  
✅ Терминология унифицирована ("pool" везде)  
✅ Код проходит линтеры без ошибок  
✅ Бот запускается без ошибок  
✅ Основные функции работают  
✅ Git commit создан с описанием изменений

---

**Готов к рефакторингу?** Начни с Этапа 1 и следуй checklist по порядку.


