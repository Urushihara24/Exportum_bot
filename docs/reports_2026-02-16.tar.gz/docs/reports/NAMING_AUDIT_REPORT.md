# 📋 ПОЛНЫЙ АУДИТ NAMING CONVENTIONS

**Дата анализа:** 2025-01-27  
**Файл:** alpha.py (30,177 строк)  
**Статистика:** 32 константы, 81 переменная, 594 функции, 45 классов

---

## 1. ИНВЕНТАРЬ ВСЕХ ИМЕН

### 1.1 ПЕРЕМЕННЫЕ (Глобальные и локальные)

#### 🔴 КРИТИЧЕСКИЕ ПРОБЛЕМЫ

├── alpha.py:131
│ ├── Текущее: `pullparticipants`
│ ├── Тип: dict
│ ├── Назначение: участники пулов
│ ├── ❌ Проблема: слитно, должно быть `pull_participants`
│ └── ✅ Предложение: `pool_participants` (более понятно)

├── alpha.py:196
│ ├── Текущее: `status_map`
│ ├── Тип: dict
│ ├── Назначение: маппинг статусов
│ ├── ❌ Проблема: lowercase, должна быть константа
│ └── ✅ Предложение: `STATUS_MAP` (перенести в константы)

├── alpha.py:102-113
│ ├── Текущее: `USERSFILE`, `BATCHESFILE`, `EXPEDITORSFILE`
│ ├── Тип: str (путь к файлу)
│ ├── ❌ Проблема: смешанный стиль (UPPER + camelCase)
│ └── ✅ Предложение: `USERS_FILE_PATH`, `BATCHES_FILE_PATH`, `EXPEDITORS_FILE_PATH`

├── alpha.py:112-113
│ ├── Текущее: `USERS_FILE`, `BATCHES_FILE` (дубликаты!)
│ ├── ❌ Проблема: дублирование с USERSFILE/BATCHESFILE
│ └── ✅ Предложение: удалить дубликаты, использовать единые имена

├── alpha.py:166-170
│ ├── Текущее: `shipping_requests`, `logistics_requests`, `logistic_offers` (дубликаты!)
│ ├── ❌ Проблема: объявлены дважды (строки 137-146 и 166-170)
│ └── ✅ Предложение: удалить дубликаты

├── alpha.py:7463
│ ├── Текущее: `gs`
│ ├── Тип: GoogleSheetsManager
│ ├── ❌ Проблема: однобуквенное имя
│ └── ✅ Предложение: `google_sheets_manager` или `sheets_manager`

#### 🟡 ВАЖНЫЕ ПРОБЛЕМЫ

├── alpha.py:127-133
│ ├── Текущее: `users`, `batches`, `pulls`, `matches`, `deals`
│ ├── Тип: dict
│ ├── ✅ Соответствует snake_case
│ └── 💡 Рекомендация: добавить суффикс `_storage` для ясности: `users_storage`, `batches_storage`

├── alpha.py:153-158
│ ├── Текущее: `batch_counter`, `pull_counter`, `deal_counter`
│ ├── Тип: int
│ ├── ✅ Соответствует стандарту
│ └── 💡 Рекомендация: `next_batch_id`, `next_pull_id` (более описательно)

├── alpha.py:161-164
│ ├── Текущее: `prices_cache`, `news_cache`
│ ├── Тип: dict
│ ├── ✅ Соответствует стандарту
│ └── ✅ OK

├── alpha.py:150-151
│ ├── Текущее: `last_start_times`, `welcome_message_ids`
│ ├── Тип: dict
│ ├── ✅ Соответствует стандарту
│ └── ✅ OK

#### 🟢 ЛОКАЛЬНЫЕ ПЕРЕМЕННЫЕ (в функциях)

├── alpha.py:295, 353
│ ├── Текущее: `migrated`, `migrated_count`
│ ├── ❌ Проблема: неконсистентность (в разных функциях разные имена)
│ └── ✅ Предложение: унифицировать в `migrated_count`

├── alpha.py:468
│ ├── Текущее: `pull_id`, `timestamp`
│ ├── ✅ OK (локальные переменные)

├── alpha.py:852
│ ├── Текущее: `max_id`
│ ├── ✅ OK

├── alpha.py:875, 903
│ ├── Текущее: `ports` (локальная)
│ ├── ❌ Проблема: конфликт с глобальной константой `PORTS`
│ └── ✅ Предложение: `user_ports` или `card_ports`

├── alpha.py:1045, 1086
│ ├── Текущее: `text`
│ ├── ❌ Проблема: слишком общее имя
│ └── ✅ Предложение: `formatted_text` или `message_text`

├── alpha.py:1696-2575 (множество мест)
│ ├── Текущее: `keyboard`
│ ├── ❌ Проблема: переиспользуется везде, может быть неоднозначно
│ └── 💡 Рекомендация: оставить как есть (локальная переменная в функциях создания клавиатур)

---

### 1.2 ФУНКЦИИ И МЕТОДЫ

#### 🔴 КРИТИЧЕСКИЕ ПРОБЛЕМЫ

├── alpha.py:1890
│ ├── Текущее: `adminkeyboard()`
│ ├── Назначение: алиас для admin_keyboard()
│ ├── ❌ Проблема: camelCase, нет подчеркивания
│ └── ✅ Предложение: удалить (есть `admin_keyboard()`)

├── alpha.py:1033
│ ├── Текущее: `generate_id()`
│ ├── Назначение: генерация ID
│ ├── ❌ Проблема: дубликат `generate_unique_id()` (строка 1023)
│ └── ✅ Предложение: удалить, использовать только `generate_unique_id()`

├── alpha.py:1169, 1178
│ ├── Текущее: `save_logistic_offers()`, `load_logistic_offers()`
│ ├── ❌ Проблема: неконсистентность (другие функции используют `logistics_offers`)
│ └── ✅ Предложение: `save_logistics_offers()`, `load_logistics_offers()`

├── alpha.py:250, 290, 351
│ ├── Текущее: `translate_pull_status()`, `migrate_all_existing_pulls()`, `migrate_old_pulls()`
│ ├── ❌ Проблема: используется "pull" вместо "pool"
│ └── 💡 Рекомендация: унифицировать терминологию (pull vs pool)

#### 🟡 ВАЖНЫЕ ПРОБЛЕМЫ

├── alpha.py:407, 449
│ ├── Текущее: `find_matching_batches()`, `_batch_matches_pull()`
│ ├── ❌ Проблема: "pull" вместо "pool"
│ └── ✅ Предложение: `find_matching_batches_for_pool()`, `_batch_matches_pool()`

├── alpha.py:869, 894
│ ├── Текущее: `get_logistics_by_port()`, `get_expeditors_by_port()`
│ ├── ✅ OK (хорошие имена)

├── alpha.py:935, 950, 974
│ ├── Текущее: `get_pull_with_participants()`, `get_farmers_from_pull()`, `get_batches_from_pull()`
│ ├── ❌ Проблема: "pull" вместо "pool"
│ └── ✅ Предложение: `get_pool_with_participants()`, `get_farmers_from_pool()`, `get_batches_from_pool()`

├── alpha.py:1634-1678
│ ├── Текущее: `validate_phone()`, `validate_email()`, `validate_inn()`, `validate_volume()`, `validate_price()`, `validate_percentage()`
│ ├── ✅ OK (хорошая консистентность)

├── alpha.py:1681-1732
│ ├── Текущее: `farmer_keyboard()`, `exporter_keyboard()`, `logistic_keyboard()`, `expeditor_keyboard()`
│ ├── ✅ OK (хорошая консистентность)

├── alpha.py:1895, 2282, 2325
│ ├── Текущее: `format_admin_statistics()`, `format_admin_analytics()`, `format_admin_users()`
│ ├── ✅ OK (хорошая консистентность)

├── alpha.py:2722, 2764
│ ├── Текущее: `format_news_message()`, `format_prices_message()`
│ ├── ✅ OK

├── alpha.py:2917
│ ├── Текущее: `find_matching_exporters()`
│ ├── ❌ Проблема: название не отражает, что ищет пулы
│ └── ✅ Предложение: `find_matching_pools_for_batch()`

#### 🟢 HANDLERS (async функции)

├── alpha.py:3180
│ ├── Текущее: `cmd_start()`
│ ├── ✅ OK (префикс `cmd_` для команд)

├── alpha.py:3405
│ ├── Текущее: `cmd_admin()`
│ ├── ✅ OK

├── alpha.py:4267, 4294
│ ├── Текущее: `registration_entry()`, `start_registration()`
│ ├── ✅ OK

├── alpha.py:4329-4486
│ ├── Текущее: `registration_name()`, `registration_phone()`, `registration_email()`, etc.
│ ├── ✅ OK (хорошая консистентность с префиксом `registration_`)

├── alpha.py:4549
│ ├── Текущее: `join_pull_start()`
│ ├── ❌ Проблема: "pull" вместо "pool"
│ └── ✅ Предложение: `join_pool_start()`

├── alpha.py:4712-4872
│ ├── Текущее: `quick_batch_start()`, `quick_batch_volume()`, `quick_batch_price()`, etc.
│ ├── ✅ OK (хорошая консистентность)

├── alpha.py:4887
│ ├── Текущее: `finish_quick_batch()`
│ ├── Параметры: `message_or_callback` (неявный тип)
│ ├── ❌ Проблема: неявный тип параметра
│ └── ✅ Предложение: добавить типизацию `Union[Message, CallbackQuery]`

---

### 1.3 КОНСТАНТЫ

#### 🔴 КРИТИЧЕСКИЕ ПРОБЛЕМЫ

├── alpha.py:196
│ ├── Текущее: `status_map` (lowercase!)
│ ├── Значение: dict статусов
│ ├── ❌ Проблема: должна быть UPPER_CASE
│ └── ✅ Предложение: `STATUS_MAP`

├── alpha.py:81
│ ├── Текущее: `CONFIG` (OK)
│ ├── ✅ Соответствует стандарту

├── alpha.py:76-79
│ ├── Текущее: `API_TOKEN`, `ADMIN_ID`, `DB_PATH`, `CHANNEL_ID`
│ ├── ✅ Соответствует стандарту

├── alpha.py:98-113
│ ├── Текущее: `DATA_DIR`, `PULLS_FILE`, `USERSFILE`, `BATCHESFILE`, `EXPEDITORSFILE`
│ ├── ❌ Проблема: неконсистентность (USERSFILE vs USERS_JSON)
│ └── ✅ Предложение: унифицировать в `USERS_PKL_FILE`, `USERS_JSON_FILE`, etc.

├── alpha.py:184-194
│ ├── Текущее: `TRANSPORT_TYPES`, `TRANSPORT_EMOJIS`
│ ├── ❌ Проблема: дублирование (одинаковые данные)
│ └── ✅ Предложение: объединить в `TRANSPORT_TYPE_EMOJIS`

├── alpha.py:211-247
│ ├── Текущее: `ROLES`, `CULTURES`, `QUALITY_CLASSES`, `STORAGE_TYPES`, `DEAL_STATUSES`, `PORTS`
│ ├── ✅ Соответствует стандарту

#### 🟡 ВАЖНЫЕ ПРОБЛЕМЫ

├── alpha.py:110-111
│ ├── Текущее: `GOOGLE_SHEETS_CREDENTIALS`, `SPREADSHEET_ID`
│ ├── ✅ OK

├── alpha.py:61
│ ├── Текущее: `LOGS_DIR`
│ ├── ✅ OK

---

### 1.4 КЛАССЫ (States и Services)

#### 🔴 КРИТИЧЕСКИЕ ПРОБЛЕМЫ

├── alpha.py:1373
│ ├── Текущее: `class AddBatch(StatesGroup):`
│ ├── ❌ Проблема: нет суффикса `States`
│ └── ✅ Предложение: `class AddBatchStates(StatesGroup):`

├── alpha.py:1387, 1394, 1400
│ ├── Текущее: `class EditBatch(StatesGroup):`, `class DeleteBatch(StatesGroup):`, `class EditProfile(StatesGroup):`
│ ├── ❌ Проблема: нет суффикса `States`
│ └── ✅ Предложение: `EditBatchStates`, `DeleteBatchStates`, `EditProfileStates`

├── alpha.py:1430, 1461
│ ├── Текущее: `class LogisticsOffer(StatesGroup):`, `class ExpeditorOffer(StatesGroup):`
│ ├── ❌ Проблема: нет суффикса `States`
│ └── ✅ Предложение: `LogisticsOfferStates`, `ExpeditorOfferStates`

├── alpha.py:1470
│ ├── Текущее: `class Broadcast(StatesGroup):`
│ ├── ❌ Проблема: нет суффикса `States`
│ └── ✅ Предложение: `BroadcastStates`

├── alpha.py:1338
│ ├── Текущее: `class SearchByCulture(StatesGroup):`
│ ├── ❌ Проблема: нет суффикса `States`
│ └── ✅ Предложение: `SearchByCultureStates`

├── alpha.py:1605, 24956
│ ├── Текущее: `class EditCardStates(StatesGroup):` (дубликат!)
│ ├── ❌ Проблема: класс объявлен дважды
│ └── ✅ Предложение: удалить один из дубликатов

├── alpha.py:28206
│ ├── Текущее: `class DealView(StatesGroup):`
│ ├── ❌ Проблема: нет суффикса `States`
│ └── ✅ Предложение: `DealViewStates`

#### 🟡 ВАЖНЫЕ ПРОБЛЕМЫ

├── alpha.py:1308
│ ├── Текущее: `class RegistrationStatesGroup(StatesGroup):`
│ ├── ✅ OK (есть суффикс `StatesGroup`)

├── alpha.py:1407, 1420
│ ├── Текущее: `class CreatePullStatesGroup(StatesGroup):`, `class JoinPullStatesGroup(StatesGroup):`
│ ├── ❌ Проблема: "pull" вместо "pool"
│ └── ✅ Предложение: `CreatePoolStatesGroup`, `JoinPoolStatesGroup`

├── alpha.py:1499
│ ├── Текущее: `class EditPullStatesGroup(StatesGroup):`
│ ├── ❌ Проблема: "pull" вместо "pool"
│ └── ✅ Предложение: `EditPoolStatesGroup`

├── alpha.py:1516, 1529
│ ├── Текущее: `class QuickBatchStatesGroup(StatesGroup):`, `class SearchBatchesStatesGroup(StatesGroup):`
│ ├── ✅ OK

├── alpha.py:6792
│ ├── Текущее: `class GoogleSheetsManager:`
│ ├── ✅ OK (PascalCase, суффикс Manager)

---

### 1.5 МОДУЛИ (Файлы)

#### 🔴 КРИТИЧЕСКИЕ ПРОБЛЕМЫ

├── alpha.py
│ ├── Текущее: `alpha.py`
│ ├── ❌ Проблема: неописательное имя, монолитный файл
│ └── ✅ Предложение: разбить на модули:
│     ├── `handlers/start_handler.py`
│     ├── `handlers/registration_handler.py`
│     ├── `handlers/pool_handler.py`
│     ├── `handlers/batch_handler.py`
│     ├── `handlers/admin_handler.py`
│     ├── `services/database_service.py`
│     ├── `services/notification_service.py`
│     ├── `services/parser_service.py`
│     ├── `keyboards/keyboards.py`
│     ├── `states/states.py`
│     └── `core/bot.py`

├── 12.py
│ ├── Текущее: `12.py`
│ ├── ❌ Проблема: неописательное имя
│ └── ✅ Предложение: удалить или переименовать

├── тесто.py
│ ├── Текущее: `тесто.py`
│ ├── ❌ Проблема: транслит, тестовый файл
│ └── ✅ Предложение: удалить или переместить в `tests/`

---

## 2. СТАТИСТИКА ПРОБЛЕМ

### По категориям:

- **🔴 Критические:** 25 проблем
- **🟡 Важные:** 18 проблем  
- **🟢 Опциональные:** 12 улучшений

### По типам:

- **Константы:** 5 проблем (status_map lowercase, дубликаты, неконсистентность)
- **Переменные:** 12 проблем (pullparticipants, дубликаты, однобуквенные)
- **Функции:** 15 проблем (pull vs pool, дубликаты, неконсистентность)
- **Классы:** 10 проблем (нет суффикса States, дубликаты)
- **Модули:** 3 проблемы (монолитный файл, неописательные имена)

---

## 3. ОСНОВНЫЕ ПАТТЕРНЫ ПРОБЛЕМ

### 3.1 Терминологическая неконсистентность
- **Проблема:** Используется и "pull" и "pool" для обозначения пула
- **Примеры:** `pulls`, `pull_id`, `CreatePullStatesGroup` vs `pool` в комментариях
- **Решение:** Унифицировать на "pool" (более понятно)

### 3.2 Дублирование
- **Проблема:** Множественные дубликаты переменных, функций, классов
- **Примеры:** 
  - `shipping_requests` объявлен дважды
  - `EditCardStates` объявлен дважды
  - `generate_id()` и `generate_unique_id()`
- **Решение:** Удалить дубликаты

### 3.3 Отсутствие суффиксов
- **Проблема:** Классы States без суффикса `States`
- **Примеры:** `AddBatch`, `EditBatch`, `DeleteBatch`
- **Решение:** Добавить суффикс `States`

### 3.4 Смешанные стили
- **Проблема:** `USERSFILE` (camelCase в UPPER) vs `USERS_JSON` (snake_case в UPPER)
- **Решение:** Унифицировать в snake_case для всех констант

### 3.5 Однобуквенные имена
- **Проблема:** `gs`, `p` (в некоторых местах)
- **Решение:** Заменить на описательные имена

---

## 4. ПРИОРИТИЗАЦИЯ РЕФАКТОРИНГА

### 🔴 КРИТИЧЕСКИЕ (блокеры читаемости)

1. **Дубликаты переменных** (строки 166-170) - удалить
2. **Дубликаты классов** (`EditCardStates`) - удалить
3. **Дубликаты функций** (`generate_id` vs `generate_unique_id`) - удалить
4. **Константа `status_map`** - переименовать в `STATUS_MAP`
5. **`pullparticipants`** - переименовать в `pool_participants`
6. **`adminkeyboard()`** - удалить (есть `admin_keyboard()`)
7. **Классы States без суффикса** - добавить суффикс `States`

### 🟡 ВАЖНЫЕ (улучшат навигацию)

8. **Унифицировать "pull" → "pool"** во всех именах
9. **Унифицировать константы файлов** (USERSFILE → USERS_PKL_FILE)
10. **Объединить TRANSPORT_TYPES и TRANSPORT_EMOJIS**
11. **Добавить типизацию** в функции без аннотаций
12. **Переименовать `gs`** → `google_sheets_manager`

### 🟢 ОПЦИОНАЛЬНЫЕ (polish)

13. **Добавить суффикс `_storage`** к глобальным словарям
14. **Переименовать счетчики** (`batch_counter` → `next_batch_id`)
15. **Группировка констант** в отдельный `config.py`

---

## 5. СЛЕДУЮЩИЕ ШАГИ

1. ✅ Создать `NAMING_STANDARD.md` с единым стандартом
2. ✅ Создать маппинг переименований (старое → новое)
3. ✅ Создать checklist для безопасного рефакторинга
4. ⏳ Выполнить рефакторинг по приоритетам


