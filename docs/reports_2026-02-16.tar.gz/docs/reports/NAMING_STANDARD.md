# 📖 ЕДИНЫЙ СТАНДАРТ ИМЕНОВАНИЯ

**Версия:** 1.0  
**Дата:** 2025-01-27  
**Проект:** Telegram-бот для зернового рынка (Aiogram)

---

## 1. ОБЩИЕ ПРАВИЛА

### 1.1 Язык именования
- ✅ **Английский язык** для всех имен (переменных, функций, классов)
- ❌ **Запрещено:** транслит, кириллица в именах
- ✅ **Исключение:** строковые значения могут быть на русском (для пользователей)

### 1.2 Стандарт кодирования
- **PEP 8** - основной стандарт
- **snake_case** для переменных и функций
- **PascalCase** для классов
- **UPPER_SNAKE_CASE** для констант

### 1.3 Запрещенные паттерны
- ❌ Однобуквенные имена (кроме циклов `i`, `j`, `k`)
- ❌ camelCase для переменных/функций
- ❌ Смешанные стили в одной категории
- ❌ Дублирование имен
- ❌ Аббревиатуры без расшифровки (кроме общепринятых: `id`, `url`, `api`)

---

## 2. ПРЕДМЕТНАЯ ОБЛАСТЬ (DOMAIN TERMS)

### 2.1 Словарь терминов

```python
DOMAIN_TERMS = {
    # Роли пользователей
    "фермер": "farmer",
    "экспортер": "exporter", 
    "логист": "logist",  # или "logistic"
    "экспедитор": "expeditor",
    
    # Бизнес-сущности
    "пулл": "pool",  # ⚠️ ВАЖНО: унифицировать на "pool", не "pull"
    "карточка": "card",
    "партия": "batch",
    "товар": "product",
    "сделка": "deal",
    "заявка": "request",
    "предложение": "offer",
    
    # Параметры зерна
    "культура": "culture",
    "натура": "test_weight",  # или "nature"
    "влажность": "moisture",
    "сорность": "weediness",  # или "impurity"
    "тоннаж": "tonnage",  # или "volume"
    "класс качества": "quality_class",
    
    # География
    "порт": "port",
    "регион": "region",
    "Астрахань": "astrakhan",
    "Новороссийск": "novorossiysk",
    
    # Процессы
    "создать пулл": "create_pool",
    "добавить в пулл": "add_to_pool",
    "закрыть пулл": "close_pool",
    "выбрать подрядчика": "select_contractor",
    "уведомление": "notification",
    
    # Статусы
    "активный": "active",
    "заполнен": "filled",
    "закрыт": "closed",
    "отменен": "cancelled",
}
```

### 2.2 Правила использования терминов

1. **Всегда используй английские термины** в именах кода
2. **Унифицируй синонимы:**
   - "пулл" → всегда `pool` (не `pull`)
   - "сорность" → `impurity` (не `weediness`)
   - "тоннаж" → `volume` (не `tonnage`)
3. **Используй полные слова**, не сокращения:
   - ✅ `user_id` (не `uid`)
   - ✅ `batch_id` (не `bid`)
   - ✅ `pool_id` (не `pid`)

---

## 3. ШАБЛОНЫ ИМЕНОВАНИЯ ПО КОНТЕКСТУ

### 3.1 HANDLERS (Обработчики сообщений/колбэков)

#### ✅ ПРАВИЛЬНО

```python
# Команды
async def handle_start_command(message: Message, state: FSMContext)
async def handle_admin_command(message: Message, state: FSMContext)

# Callback handlers
async def handle_pool_creation_start(callback: CallbackQuery, state: FSMContext)
async def handle_batch_join_callback(callback: CallbackQuery, state: FSMContext)

# Message handlers (FSM states)
async def process_registration_name(message: Message, state: FSMContext)
async def process_pool_volume_input(message: Message, state: FSMContext)
async def process_farmer_card_photo(message: Message, state: FSMContext)
```

#### ❌ НЕПРАВИЛЬНО

```python
async def start(msg)  # слишком общее, нет типов
async def pool(call)  # неясно что делает
async def photo_handler(m)  # неявные типы
```

**Паттерн:** `handle_{action}_{entity}` или `process_{entity}_{field}`

---

### 3.2 STATES (FSM состояния)

#### ✅ ПРАВИЛЬНО

```python
class PoolCreationStates(StatesGroup):
    waiting_for_culture = State()
    waiting_for_tonnage = State()
    waiting_for_port_selection = State()
    waiting_for_price = State()

class BatchCreationStates(StatesGroup):
    selecting_culture = State()
    entering_volume = State()
    entering_price = State()
    entering_quality_params = State()
```

#### ❌ НЕПРАВИЛЬНО

```python
class Pool(StatesGroup):  # нет суффикса States
    step1 = State()  # неописательно
    culture = State()  # неясно что ожидается
```

**Правила:**
- Всегда суффикс `States` или `StatesGroup`
- Имена состояний: `waiting_for_{field}` или `entering_{field}` или `selecting_{field}`

---

### 3.3 DATABASE функции (CRUD)

#### ✅ ПРАВИЛЬНО

```python
# Получение
async def get_user_by_telegram_id(telegram_id: int) -> dict
async def get_pool_by_id(pool_id: int) -> dict
async def get_batches_by_farmer_id(farmer_id: int) -> list[dict]

# Создание
async def create_farmer_card(user_id: int, card_data: dict) -> str
async def create_pool(exporter_id: int, pool_data: dict) -> int

# Обновление
async def update_pool_tonnage(pool_id: int, added_tonnage: float) -> bool
async def update_batch_status(batch_id: int, new_status: str) -> bool

# Удаление
async def delete_user_account(user_id: int) -> bool
async def delete_pool(pool_id: int) -> bool
```

#### ❌ НЕПРАВИЛЬНО

```python
async def get_user(id)  # нет типов, неясно какой ID
async def create_card(data)  # неясно что создается
async def update(pool, amount)  # слишком общее
```

**Паттерн:** `{action}_{entity}_by_{field}({field}: type) -> return_type`

---

### 3.4 VALIDATION функции

#### ✅ ПРАВИЛЬНО

```python
def validate_phone_number(phone: str) -> bool
def validate_email_address(email: str) -> bool
def validate_inn_number(inn: str) -> bool
def validate_volume_amount(volume: float) -> bool
def validate_price_value(price: float) -> bool
def validate_percentage_value(value: float) -> bool
```

**Паттерн:** `validate_{field}_{type}({field}: type) -> bool`

---

### 3.5 KEYBOARD функции

#### ✅ ПРАВИЛЬНО

```python
def create_farmer_keyboard() -> ReplyKeyboardMarkup
def create_exporter_keyboard() -> ReplyKeyboardMarkup
def create_pool_join_keyboard(pool_id: int) -> InlineKeyboardMarkup
def create_batch_actions_keyboard(batch_id: int) -> InlineKeyboardMarkup
def create_port_selection_keyboard() -> InlineKeyboardMarkup
```

#### ❌ НЕПРАВИЛЬНО

```python
def farmer_keyboard()  # нет префикса create_, нет типа возврата
def keyboard()  # слишком общее
```

**Паттерн:** `create_{role/entity}_{purpose}_keyboard(...) -> KeyboardType`

---

### 3.6 FORMAT функции

#### ✅ ПРАВИЛЬНО

```python
def format_pool_card(pool_id: int, pool_data: dict) -> str
def format_batch_info(batch_id: int, batch_data: dict) -> str
def format_admin_statistics(users: dict, pools: dict) -> str
def format_prices_message(prices_data: dict) -> str
def format_news_message(news_list: list[dict]) -> str
```

**Паттерн:** `format_{entity}_{purpose}(...) -> str`

---

### 3.7 NOTIFICATION функции

#### ✅ ПРАВИЛЬНО

```python
async def send_pool_created_notification(exporter_id: int, pool_id: int) -> bool
async def send_pool_filled_notification(pool_id: int, participants: list[int]) -> bool
async def send_contractor_selected_notification(user_id: int, deal_id: int) -> bool
async def notify_all_pool_participants(pool_id: int, message: str) -> int
```

**Паттерн:** `send_{event}_notification(...)` или `notify_{target}_{event}(...)`

---

## 4. КОНСТАНТЫ ПО КАТЕГОРИЯМ

### 4.1 Роли пользователей

```python
USER_ROLE_FARMER = "farmer"
USER_ROLE_EXPORTER = "exporter"
USER_ROLE_LOGIST = "logistic"
USER_ROLE_EXPEDITOR = "expeditor"

USER_ROLES = {
    USER_ROLE_FARMER: "🌾 Фермер",
    USER_ROLE_EXPORTER: "📦 Экспортёр",
    USER_ROLE_LOGIST: "🚚 Логист",
    USER_ROLE_EXPEDITOR: "🚛 Экспедитор / Таможенный Брокер",
}
```

### 4.2 Порты

```python
PORT_ASTRAKHAN = "Астрахань"
PORT_NOVOROSSIYSK = "Новороссийск"
PORT_ARIB = "Ариб"
# ... остальные порты

AVAILABLE_PORTS = [
    PORT_ASTRAKHAN,
    PORT_NOVOROSSIYSK,
    PORT_ARIB,
    # ... остальные
]
```

### 4.3 Культуры

```python
CULTURE_WHEAT = "Пшеница"
CULTURE_BARLEY = "Ячмень"
CULTURE_CORN = "Кукуруза"
CULTURE_SUNFLOWER = "Подсолнечник"
CULTURE_RAPESEED = "Рапс"
CULTURE_SOYBEAN = "Соя"

AVAILABLE_CULTURES = [
    CULTURE_WHEAT,
    CULTURE_BARLEY,
    CULTURE_CORN,
    CULTURE_SUNFLOWER,
    CULTURE_RAPESEED,
    CULTURE_SOYBEAN,
]
```

### 4.4 Статусы пулов

```python
POOL_STATUS_ACTIVE = "active"
POOL_STATUS_FILLED = "filled"
POOL_STATUS_CLOSED = "closed"
POOL_STATUS_COMPLETED = "completed"
POOL_STATUS_CANCELLED = "cancelled"

POOL_STATUS_MAP = {
    POOL_STATUS_ACTIVE: "🟢 Активный",
    POOL_STATUS_FILLED: "🎉 Заполнен",
    POOL_STATUS_CLOSED: "🔴 Закрыт",
    POOL_STATUS_COMPLETED: "✔️ Завершён",
    POOL_STATUS_CANCELLED: "❌ Отменён",
}
```

### 4.5 Лимиты пулов

```python
MAX_POOL_TONNAGE = 10000  # максимальный тоннаж пула
MIN_POOL_TONNAGE = 100    # минимальный тоннаж пула
POOL_AUTO_CLOSE_THRESHOLD = 0.95  # 95% от целевого тоннажа для автозакрытия
```

### 4.6 Пути к файлам

```python
# Директории
DATA_DIRECTORY = "data"
LOGS_DIRECTORY = "logs"

# Файлы данных (pickle)
USERS_PKL_FILE = os.path.join(DATA_DIRECTORY, "users.pkl")
BATCHES_PKL_FILE = os.path.join(DATA_DIRECTORY, "batches.pkl")
POOLS_PKL_FILE = os.path.join(DATA_DIRECTORY, "pools.pkl")  # ⚠️ было pulls.pkl

# Файлы данных (JSON)
USERS_JSON_FILE = os.path.join(DATA_DIRECTORY, "users.json")
BATCHES_JSON_FILE = os.path.join(DATA_DIRECTORY, "batches.json")
POOLS_JSON_FILE = os.path.join(DATA_DIRECTORY, "pools.json")
PRICES_JSON_FILE = os.path.join(DATA_DIRECTORY, "prices.json")
NEWS_JSON_FILE = os.path.join(DATA_DIRECTORY, "news.json")
```

### 4.7 Google Sheets

```python
GOOGLE_SHEETS_CREDENTIALS_FILE = "credentials.json"
GOOGLE_SHEETS_SPREADSHEET_ID = "1DywxtuWW4-1Q0O71ajVaBB5Ih15nZjA4rvlpV7P7NOA"
GOOGLE_SHEETS_AVAILABLE = True  # или False
```

---

## 5. ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ (Storage)

### 5.1 Хранилища данных

```python
# Основные хранилища
users_storage: dict[int, dict] = {}
batches_storage: dict[int, list[dict]] = {}
pools_storage: dict[int, dict] = {}  # ⚠️ было pulls
pool_participants_storage: dict[int, list[dict]] = {}  # ⚠️ было pullparticipants
matches_storage: dict[str, dict] = {}
deals_storage: dict[int, list[dict]] = {}

# Логистика
shipping_requests_storage: dict[str, dict] = {}
logistics_requests_storage: dict[str, dict] = {}
farmer_logistics_requests_storage: dict[str, dict] = {}
farmer_shipping_requests_storage: dict[str, dict] = {}

# Карточки и предложения
logistics_cards_storage: dict[int, dict] = {}
expeditor_cards_storage: dict[int, dict] = {}
expeditor_offers_storage: dict[str, dict] = {}
logistics_offers_storage: dict[str, dict] = {}

# Счетчики ID
next_batch_id: int = 1
next_pool_id: int = 1  # ⚠️ было pull_counter
next_deal_id: int = 1
next_match_id: int = 1
next_logistics_request_id: int = 1
next_logistics_offer_id: int = 1
next_expeditor_pull_offer_id: int = 1
next_expeditor_request_offer_id: int = 1

# Кэш
prices_cache: dict = {"data": {}, "updated": None}
news_cache: dict = {"data": [], "updated": None}
last_prices_update_time: datetime | None = None
last_news_update_time: datetime | None = None
```

**Правило:** Добавлять суффикс `_storage` для глобальных словарей данных

---

## 6. ТИПИЗАЦИЯ

### 6.1 Обязательные аннотации типов

```python
# ✅ ПРАВИЛЬНО
async def create_pool(
    exporter_id: int,
    culture: str,
    target_volume: float,
    price_per_ton: float
) -> int:
    ...

# ❌ НЕПРАВИЛЬНО
async def create_pool(exporter_id, culture, target_volume, price_per_ton):
    ...
```

### 6.2 Использование Union для множественных типов

```python
from typing import Union

async def handle_message_or_callback(
    data: Union[Message, CallbackQuery],
    state: FSMContext
) -> None:
    ...
```

### 6.3 Optional для необязательных параметров

```python
from typing import Optional

def get_user_by_id(
    user_id: int,
    include_batches: Optional[bool] = False
) -> Optional[dict]:
    ...
```

---

## 7. ПРЕФИКСЫ И СУФФИКСЫ

### 7.1 Префиксы функций

- `handle_` - обработчики событий (handlers)
- `process_` - обработка данных/ввода (FSM states)
- `create_` - создание объектов (keyboards, entities)
- `get_` - получение данных
- `save_` - сохранение данных
- `load_` - загрузка данных
- `update_` - обновление данных
- `delete_` - удаление данных
- `validate_` - валидация
- `format_` - форматирование для отображения
- `send_` - отправка (notifications, messages)
- `notify_` - уведомления
- `parse_` - парсинг данных
- `find_` - поиск
- `check_` - проверка условий

### 7.2 Суффиксы

- `_storage` - глобальные хранилища данных
- `_cache` - кэш
- `_counter` → `_id` - счетчики (лучше `next_{entity}_id`)
- `States` или `StatesGroup` - FSM состояния
- `Manager` - классы-менеджеры (GoogleSheetsManager)
- `Service` - сервисные классы
- `Handler` - обработчики (если в отдельных файлах)

---

## 8. ПРИМЕРЫ ПРАВИЛЬНОГО ИМЕНОВАНИЯ

### 8.1 Полный пример handler

```python
@dp.callback_query_handler(
    lambda c: c.data.startswith("join_pool:"),
    state="*"
)
async def handle_pool_join_start(
    callback: CallbackQuery,
    state: FSMContext
) -> None:
    """Обработка начала присоединения к пулу"""
    user_id = callback.from_user.id
    pool_id = parse_callback_id(callback.data)
    
    if pool_id is None:
        await callback.answer("❌ Ошибка", show_alert=True)
        return
    
    pool_data = get_pool_by_id(pool_id)
    if not pool_data:
        await callback.answer("❌ Пул не найден", show_alert=True)
        return
    
    await state.set_state(PoolJoinStates.selecting_batch)
    await state.update_data(pool_id=pool_id)
    
    # Показать клавиатуру выбора партии
    keyboard = create_batch_selection_keyboard(user_id)
    await callback.message.edit_text(
        "Выберите партию для добавления в пул:",
        reply_markup=keyboard
    )
```

### 8.2 Полный пример States

```python
class PoolCreationStates(StatesGroup):
    """Состояния создания пула экспортёром"""
    
    waiting_for_culture = State()
    waiting_for_target_volume = State()
    waiting_for_price_per_ton = State()
    waiting_for_port_selection = State()
    waiting_for_moisture = State()
    waiting_for_test_weight = State()
    waiting_for_impurity = State()
    waiting_for_weed = State()
    waiting_for_documents = State()
    confirming_creation = State()
```

### 8.3 Полный пример Service

```python
class GoogleSheetsService:
    """Сервис для работы с Google Sheets"""
    
    def __init__(self, credentials_file: str, spreadsheet_id: str):
        self.credentials_file = credentials_file
        self.spreadsheet_id = spreadsheet_id
        self.client: Optional[gspread.Client] = None
        self.spreadsheet: Optional[gspread.Spreadsheet] = None
    
    async def sync_user_to_sheets(
        self,
        user_id: int,
        user_data: dict
    ) -> bool:
        """Синхронизация пользователя с Google Sheets"""
        ...
    
    async def sync_batch_to_sheets(
        self,
        batch_data: dict
    ) -> bool:
        """Синхронизация партии с Google Sheets"""
        ...
```

---

## 9. ЗАПРЕЩЕННЫЕ ПАТТЕРНЫ

### ❌ НЕ ИСПОЛЬЗУЙ:

1. **Однобуквенные имена** (кроме циклов):
   ```python
   # ❌
   gs = GoogleSheetsManager()
   p = pool_data
   
   # ✅
   sheets_manager = GoogleSheetsManager()
   pool_data = get_pool_by_id(pool_id)
   ```

2. **camelCase для переменных/функций**:
   ```python
   # ❌
   userData = {}
   def getUserData():
   
   # ✅
   user_data = {}
   def get_user_data():
   ```

3. **Смешанные языки**:
   ```python
   # ❌
   def создать_пулл():
   def sozdat_pull():
   
   # ✅
   def create_pool():
   ```

4. **Аббревиатуры без контекста**:
   ```python
   # ❌
   def get_usr(id):
   def crt_pool(data):
   
   # ✅
   def get_user(user_id: int):
   def create_pool(pool_data: dict):
   ```

5. **Дублирование имен**:
   ```python
   # ❌
   shipping_requests = {}  # строка 137
   shipping_requests = {}  # строка 166 (дубликат!)
   
   # ✅
   shipping_requests_storage = {}  # только один раз
   ```

---

## 10. МИГРАЦИЯ СУЩЕСТВУЮЩЕГО КОДА

### 10.1 Порядок переименования

1. **Константы** (низкий риск)
2. **Глобальные переменные** (средний риск)
3. **Классы States** (средний риск)
4. **Функции** (высокий риск - много вызовов)
5. **Локальные переменные** (низкий риск)
6. **Модули** (последними - меняют импорты)

### 10.2 Инструменты

- **IDE Refactor** (PyCharm, VSCode) - автоматическое переименование
- **grep/sed** - массовая замена в файлах
- **mypy** - проверка типов после переименования
- **pytest** - запуск тестов после изменений

---

## 11. CHECKLIST ПЕРЕИМЕНОВАНИЯ

- [ ] Создан git commit (бэкап)
- [ ] Проверены все импорты
- [ ] Учтены строковые ссылки (callback_data, database keys)
- [ ] Обновлены типы в аннотациях
- [ ] Запущены линтеры (flake8, pylint, mypy)
- [ ] Обновлена документация/комментарии
- [ ] Протестированы основные функции
- [ ] Code review перед merge

---

**Следующий шаг:** Использовать `RENAMING_MAPPING.md` для массового рефакторинга


